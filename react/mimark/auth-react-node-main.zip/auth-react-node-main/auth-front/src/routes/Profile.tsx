import PortalLayout from "../layout/PortalLayout";

export default function Profile() {
  return (
    <PortalLayout>
      <h1>Profile</h1>
    </PortalLayout>
  );
}
